/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2014, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGPoolingDataSource;

public class PoolingDataSource extends PGPoolingDataSource
{
}
