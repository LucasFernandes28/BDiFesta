/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2014, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/

package org.postgresql.jdbc2.optional;

import org.postgresql.ds.PGConnectionPoolDataSource;

public class ConnectionPool extends PGConnectionPoolDataSource
{
}
